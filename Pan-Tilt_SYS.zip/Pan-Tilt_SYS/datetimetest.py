import datetime

mytime = datetime.datetime.now()
mytime1 = mytime - datetime.timedelta(minutes=5)
dd = mytime1.strftime('%Y/%m/%d %H:%M:%S')+"(0)"
print(dd)
