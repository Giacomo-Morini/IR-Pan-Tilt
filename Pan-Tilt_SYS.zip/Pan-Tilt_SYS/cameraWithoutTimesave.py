import subprocess

status = subprocess.call('raspistill -ISO 800 -w 3280 -h 2464 -q 100 -r -ss 10000 -vf -o bb.jpg', shell =True)
print(status)