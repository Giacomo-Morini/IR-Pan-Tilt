import pandas as pd
df = pd.read_csv("/home/pi/Desktop/IRvals.csv" )
df