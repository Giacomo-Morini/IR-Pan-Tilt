import serial

ser = serial.Serial('/dev/ttyUSB3',9600)
ser.flushInput()


while True:
    ser.write(90)